library(testthat)
library(phaseR)

test_check("phaseR")
